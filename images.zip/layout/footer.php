<?php
echo '<footer class="footer">
  <p class="has-text-centered has-text-weight-light">
    Made with ❤ by Kelompok 6 PAW kls C<br/><br/>
    Alisha Aileen | Alexander Rivelino | Raditya Dimas | Yanuarius Hermawan
  </p>
</footer>';
?>