<?php include '../layout/dashboard.php';?>
  <div id="dashboardData">
    This is dashboard
  </div>
</body>
<script src="../script/script.js"></script>
<script>
  var elm = document.getElementById("dashboardTab").classList.add("isActive")
</script>
</html>